html files in this folder are generated from templates and build system in repo_root/emails
